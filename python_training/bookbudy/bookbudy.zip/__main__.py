# bookbuddy/main.py
from datetime import datetime
from bookbuddy.models.book import Book, BookError
from bookbuddy.models.reading_log import ReadingLog
from bookbuddy.services.reading_tracker import ReadingTracker, ReadingTrackerError
from bookbuddy.services.progress_manager import ProgressManager
from bookbuddy.storage.data_exporter import DataExporter

library = []
tracker = ReadingTracker()
progress_manager = ProgressManager(tracker)
exporter = DataExporter()

def add_book():
    print("\n📘 Add a New Book\n")
    title = input("Enter book title: ").strip()
    author = input("Enter author name: ").strip()
    genre = input("Enter genre: ").strip()
    pages = int(input("Enter total pages: ").strip())

    book = Book(title, author, genre, pages, datetime.now())
    library.append(book)
    print(f"\n✅ Book '{title}' added successfully!")

def view_books():
    print("\n📚 Your Library:\n")
    if not library:
        print("No books added yet.")
        return
    for i, book in enumerate(library, start=1):
        print(f"{i}. {book}")

def log_progress():
    print("\n📖 Log Reading Progress\n")
    title = input("Enter book title: ").strip()
    pages_read = int(input("Enter pages read: ").strip())
    notes = input("Enter notes (optional): ").strip()

    log = ReadingLog(book_title=title, pages_read=pages_read, notes=notes)
    tracker.add_log(log)
    print("\n✅ Reading log added!")

def view_progress():
    print("\n📈 Reading Progress:\n")
    if not library:
        print("No books added yet.")
        return

    for book in library:
        p = progress_manager.calculate_progress(book)
        print(f"{book.title} - {p['read_pages']}/{p['total_pages']} pages read ({p['percent']:.1f}%)")

def export_data():
    print("\n📤 Export Book Data\n")
    print("Choose format:\n1. JSON\n2. Pickle")
    choice = input("Enter choice (1-2): ").strip()
    fmt = "json" if choice == "1" else "pickle"
    filename = input("Enter filename: ").strip()

    exporter.export(library, filename, fmt)
    print(f"\n✅ Data exported to '{filename}'")

def import_data():
    print("\n📥 Import Book Data\n")
    print("Choose format:\n1. JSON\n2. Pickle")
    choice = input("Enter choice (1-2): ").strip()
    fmt = "json" if choice == "1" else "pickle"
    filename = input("Enter filename: ").strip()

    data = exporter.import_data(filename, fmt)
    print("\n✅ Data imported successfully!")
    print(data)

def main():
    print("📚 Welcome to BookBuddy!")
    print("Track your reading, log progress, and manage your personal library.\n")

    while True:
        print("\nMain Menu:")
        print("1. Add a new book")
        print("2. View all books")
        print("3. Log reading progress")
        print("4. View reading progress")
        print("5. Export book data")
        print("6. Import book data")
        print("7. Exit")

        choice = input("\nEnter your choice (1-7): ").strip()

        try:
            if choice == "1":
                add_book()
            elif choice == "2":
                view_books()
            elif choice == "3":
                log_progress()
            elif choice == "4":
                view_progress()
            elif choice == "5":
                export_data()
            elif choice == "6":
                import_data()
            elif choice == "7":
                print("\nGoodbye 👋")
                break
            else:
                print("❌ Invalid choice. Try again.")
        except (BookError, ReadingTrackerError, ValueError) as e:
            print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()
